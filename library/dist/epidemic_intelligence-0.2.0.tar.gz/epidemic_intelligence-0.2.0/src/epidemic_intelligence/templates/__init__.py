# allows `from epigraph.templates import netsi`
from .netsi import netsi 
