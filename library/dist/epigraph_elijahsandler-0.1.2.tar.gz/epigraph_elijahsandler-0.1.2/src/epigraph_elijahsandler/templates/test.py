import os
import platform
import shutil
import sys

def install_font(font_file):
    """Install the specified font to the user's font manager."""
    system = platform.system()
    font_dir = ""

    if system == "Windows":
        font_dir = os.path.join(os.environ['LOCALAPPDATA'], 'Microsoft', 'Windows', 'Fonts')
    elif system == "Darwin":  # macOS
        font_dir = os.path.join(os.path.expanduser('~'), 'Library', 'Fonts')
    elif system == "Linux":
        font_dir = os.path.join(os.path.expanduser('~'), '.fonts')
        os.makedirs(font_dir, exist_ok=True)  # Create the .fonts directory if it doesn't exist
    else:
        print("Unsupported operating system. Please install the font manually.")
        return

    # Define the destination font file path
    dest_font_file = os.path.join(font_dir, os.path.basename(font_file))

    # Attempt to copy the font file to the appropriate directory
    try:
        if not os.path.exists(dest_font_file):  # Check if the font is already installed
            shutil.copy(font_file, dest_font_file)
            print(f"Successfully installed '{os.path.basename(font_file)}' to '{font_dir}'.")
        else:
            print(f"The font '{os.path.basename(font_file)}' is already installed.")
    except PermissionError:
        print(f"Permission denied: Unable to install font to '{font_dir}'. Please ensure you have write permissions.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    else:
        print("Font installation completed successfully.")

if __name__ == "__main__":
    # Get the path to the font file (this should be adjusted based on your package structure)
    font_file_path = r"C:\Users\elija\Documents\24f-coop\viz-book-public\library\src\epigraph_elijahsandler\fonts\BarlowSemiCondensed-Light.ttf"
    install_font(font_file_path)